const api = globalThis.browser || globalThis.chrome
const t = (key) => api.i18n.getMessage(key) || key
const ICON_SIZE = 22
const attached = new WeakSet()
let host = null
let shadow = null
let iconEl = null
let panelEl = null
let anchorField = null
let activePassword = null

const ICON_SVG = `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`

function ensureHost() {
  if (host) return
  host = document.createElement('div')
  host.style.cssText = 'all:initial;position:absolute;top:0;left:0;z-index:2147483647;'
  shadow = host.attachShadow({ mode: 'open' })
  const style = document.createElement('style')
  style.textContent = `
    :host { all: initial; }
    .rp-icon {
      position: absolute; display: flex; align-items: center; justify-content: center;
      width: ${ICON_SIZE}px; height: ${ICON_SIZE}px; border-radius: 7px; cursor: pointer;
      background: #0c0c0f; color: #34d399; border: 1px solid rgba(52,211,153,.35);
      box-shadow: 0 2px 8px rgba(0,0,0,.35); transition: background .15s, transform .15s;
      font-family: system-ui, sans-serif;
    }
    .rp-icon:hover { background: #14141a; transform: translateY(-1px); }
    .rp-panel {
      position: absolute; min-width: 240px; max-width: 320px; max-height: 320px; overflow-y: auto;
      background: #0c0c0f; border: 1px solid rgba(255,255,255,.08); border-radius: 14px;
      box-shadow: 0 16px 48px rgba(0,0,0,.6); padding: 6px; color: #e4e4e7;
      font-family: system-ui, sans-serif; font-size: 13px;
    }
    .rp-head { padding: 8px 10px 6px; font-size: 11px; letter-spacing: .04em; text-transform: uppercase; color: #71717a; }
    .rp-item {
      display: flex; align-items: center; gap: 10px; padding: 9px 10px; border-radius: 10px;
      cursor: pointer; transition: background .12s;
    }
    .rp-item:hover { background: rgba(255,255,255,.05); }
    .rp-logo {
      width: 26px; height: 26px; border-radius: 8px; flex: none; display: flex; align-items: center;
      justify-content: center; background: rgba(52,211,153,.12); color: #34d399; font-weight: 700; font-size: 12px;
    }
    .rp-meta { min-width: 0; }
    .rp-title { font-weight: 600; color: #fafafa; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .rp-sub { color: #71717a; font-size: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .rp-empty { padding: 12px 10px; color: #71717a; font-size: 12px; }
    .rp-2fa { margin-left: auto; flex: none; font-size: 10px; color: #34d399; border: 1px solid rgba(52,211,153,.3); border-radius: 999px; padding: 1px 6px; }
  `
  shadow.appendChild(style)
  document.documentElement.appendChild(host)
}

function isVisible(el) {
  if (!el) return false
  const rect = el.getBoundingClientRect()
  if (rect.width < 8 || rect.height < 8) return false
  const cs = getComputedStyle(el)
  return cs.visibility !== 'hidden' && cs.display !== 'none' && el.type !== 'hidden'
}

function isUsernameLike(el) {
  if (!isVisible(el)) return false
  const type = (el.getAttribute('type') || 'text').toLowerCase()
  if (type === 'email') return true
  if (!['text', 'tel', 'username', ''].includes(type)) return false
  const ac = (el.autocomplete || el.getAttribute('autocomplete') || '').toLowerCase()
  if (ac === 'username' || ac === 'email') return true
  const hint = (
    el.name +
    ' ' +
    el.id +
    ' ' +
    (el.placeholder || '') +
    ' ' +
    (el.getAttribute('aria-label') || '')
  ).toLowerCase()
  return /e-?mail|user|login|identifi|account|t[ée]l|phone|mobile/.test(hint)
}

function findUsernameFor(passwordField) {
  const scope = passwordField.form || document
  const candidates = [...scope.querySelectorAll('input')].filter((el) => {
    const type = (el.getAttribute('type') || 'text').toLowerCase()
    return ['text', 'email', 'tel', 'username', ''].includes(type) && isVisible(el)
  })
  let best = null
  for (const el of candidates) {
    const pos = el.compareDocumentPosition(passwordField)
    if (pos & Node.DOCUMENT_POSITION_FOLLOWING) best = el
  }
  return best || candidates[0] || null
}

function findUsernameField() {
  const inputs = [...document.querySelectorAll('input')]
  const likes = inputs.filter(isUsernameLike)
  if (likes.length) return likes[0]
  const textish = inputs.filter((el) => {
    const type = (el.getAttribute('type') || 'text').toLowerCase()
    return ['text', 'email', 'tel', ''].includes(type) && isVisible(el)
  })
  return textish.length === 1 ? textish[0] : null
}

function nativeSetValue(el, value) {
  const proto =
    el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
  const setter = Object.getOwnPropertyDescriptor(proto, 'value').set
  setter.call(el, value)
  el.dispatchEvent(new Event('input', { bubbles: true }))
  el.dispatchEvent(new Event('change', { bubbles: true }))
}

function fillFields(secret) {
  let pwd =
    activePassword && document.contains(activePassword) && isVisible(activePassword)
      ? activePassword
      : null
  if (!pwd) pwd = [...document.querySelectorAll('input[type="password"]')].find(isVisible) || null

  let user = pwd ? findUsernameFor(pwd) : null
  if (!user) {
    const af = document.activeElement
    user = af && af.tagName === 'INPUT' && isUsernameLike(af) ? af : findUsernameField()
  }

  if (user && secret.login) {
    user.focus()
    nativeSetValue(user, secret.login)
  }
  if (pwd && secret.password) {
    pwd.focus()
    nativeSetValue(pwd, secret.password)
  }
  if (secret.totp) {
    const otp = [...document.querySelectorAll('input')].find(
      (el) =>
        isVisible(el) &&
        (el.autocomplete === 'one-time-code' || /otp|totp|2fa|code/i.test(el.name + ' ' + el.id))
    )
    if (otp) nativeSetValue(otp, secret.totp)
  }
  hidePanel()
}

function positionIcon() {
  if (!iconEl || !anchorField || !document.contains(anchorField)) {
    hideIcon()
    return
  }
  const rect = anchorField.getBoundingClientRect()
  if (rect.width < 8) {
    hideIcon()
    return
  }
  const top = window.scrollY + rect.top + (rect.height - ICON_SIZE) / 2
  const left = window.scrollX + rect.right - ICON_SIZE - 8
  iconEl.style.top = top + 'px'
  iconEl.style.left = left + 'px'
}

function showIconFor(field) {
  ensureHost()
  anchorField = field
  if (!iconEl) {
    iconEl = document.createElement('div')
    iconEl.className = 'rp-icon'
    iconEl.innerHTML = ICON_SVG
    iconEl.title = 'RootPass'
    iconEl.addEventListener('mousedown', (e) => {
      e.preventDefault()
      e.stopPropagation()
      togglePanel()
    })
    shadow.appendChild(iconEl)
  }
  iconEl.style.display = 'flex'
  positionIcon()
}

function hideIcon() {
  if (iconEl) iconEl.style.display = 'none'
}

function hidePanel() {
  if (panelEl) {
    panelEl.remove()
    panelEl = null
  }
}

async function togglePanel() {
  if (panelEl) {
    hidePanel()
    return
  }
  ensureHost()
  panelEl = document.createElement('div')
  panelEl.className = 'rp-panel'
  panelEl.innerHTML = `<div class="rp-empty">${t('contentLoading')}</div>`
  shadow.appendChild(panelEl)
  positionPanel()

  let res
  try {
    res = await api.runtime.sendMessage({ cmd: 'query', url: location.href })
  } catch {
    res = { error: 'disconnected' }
  }
  if (!panelEl) return

  if (res && res.error === 'locked') {
    panelEl.innerHTML = `<div class="rp-empty">${t('contentLocked')}</div>`
    return
  }
  if (!res || res.error || !res.items) {
    panelEl.innerHTML = `<div class="rp-empty">${t('contentNotConnected')}</div>`
    return
  }
  if (!res.items.length) {
    panelEl.innerHTML = `<div class="rp-empty">${t('contentNoAccounts')}</div>`
    return
  }

  panelEl.innerHTML = `<div class="rp-head">${t('contentAccountsForSite')}</div>`
  for (const item of res.items) {
    const row = document.createElement('div')
    row.className = 'rp-item'
    const initials = (item.title || '?').trim().slice(0, 2).toUpperCase()
    row.innerHTML = `
      <div class="rp-logo">${initials}</div>
      <div class="rp-meta">
        <div class="rp-title"></div>
        <div class="rp-sub"></div>
      </div>
      ${item.hasTotp ? '<span class="rp-2fa">2FA</span>' : ''}
    `
    row.querySelector('.rp-title').textContent = item.title || ''
    row.querySelector('.rp-sub').textContent = item.login || ''
    row.addEventListener('mousedown', async (e) => {
      e.preventDefault()
      const fillRes = await api.runtime.sendMessage({
        cmd: 'fill',
        id: item.id,
        fields: ['login', 'password', 'totp']
      })
      if (fillRes && fillRes.secret) fillFields(fillRes.secret)
    })
    panelEl.appendChild(row)
  }
}

function positionPanel() {
  if (!panelEl || !anchorField) return
  const rect = anchorField.getBoundingClientRect()
  panelEl.style.top = window.scrollY + rect.bottom + 6 + 'px'
  panelEl.style.left = window.scrollX + rect.left + 'px'
}

function attachField(field, kind) {
  if (attached.has(field)) return
  attached.add(field)
  const onFocus = () => {
    if (kind === 'password') activePassword = field
    showIconFor(field)
  }
  field.addEventListener('focus', onFocus)
  if (field === document.activeElement) onFocus()
}

function scan() {
  const pwds = [...document.querySelectorAll('input[type="password"]')].filter(isVisible)
  for (const p of pwds) attachField(p, 'password')
  const users = [...document.querySelectorAll('input')].filter(isUsernameLike)
  for (const u of users) attachField(u, 'username')
}

let scanTimer = null
function scheduleScan() {
  clearTimeout(scanTimer)
  scanTimer = setTimeout(scan, 400)
}

const observer = new MutationObserver(scheduleScan)
observer.observe(document.documentElement, { childList: true, subtree: true })

window.addEventListener(
  'scroll',
  () => {
    positionIcon()
    positionPanel()
  },
  true
)
window.addEventListener('resize', () => {
  positionIcon()
  positionPanel()
})
document.addEventListener('mousedown', (e) => {
  if (panelEl && host && !e.composedPath().includes(host)) hidePanel()
})

api.runtime.onMessage.addListener((msg) => {
  if (msg && msg.cmd === 'doFill' && msg.secret) fillFields(msg.secret)
})

scan()
