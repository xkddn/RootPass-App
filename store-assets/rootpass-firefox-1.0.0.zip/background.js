const api = globalThis.browser || globalThis.chrome
const BASE_PORT = 17872
const PORT_TRIES = 10
const RECONNECT_MIN = 1000
const RECONNECT_MAX = 15000

let ws = null
let wsState = 'disconnected'
let appState = 'unknown'
let token = null
let pendingCode = null
let reconnectDelay = RECONNECT_MIN
let reconnectTimer = null
let discoveryIndex = 0
let foundPort = null
let failuresSinceFound = 0

let reqCounter = 0
const pending = new Map()
const pairWaiters = []

function nextReqId() {
  reqCounter += 1
  return reqCounter
}

async function loadToken() {
  const data = await api.storage.local.get('token')
  token = typeof data.token === 'string' ? data.token : null
}

function setState(next) {
  appState = next
  broadcastState()
}

function broadcastState() {
  api.runtime.sendMessage({ type: 'state', wsState, appState }).catch(() => {})
}

function hexFromBuffer(buffer) {
  return [...new Uint8Array(buffer)].map((b) => b.toString(16).padStart(2, '0')).join('')
}

async function hmacHex(key, message) {
  const enc = new TextEncoder()
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    enc.encode(key),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  )
  const sig = await crypto.subtle.sign('HMAC', cryptoKey, enc.encode(message))
  return hexFromBuffer(sig)
}

function send(payload) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(payload))
    return true
  }
  return false
}

function connect() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return
  clearTimeout(reconnectTimer)
  wsState = 'connecting'
  const port = foundPort != null ? foundPort : BASE_PORT + (discoveryIndex % PORT_TRIES)
  let socket
  let opened = false
  try {
    socket = new WebSocket('ws://127.0.0.1:' + port)
  } catch {
    scheduleReconnect(false)
    return
  }
  ws = socket

  socket.onopen = () => {
    opened = true
    foundPort = port
    failuresSinceFound = 0
    wsState = 'open'
    reconnectDelay = RECONNECT_MIN
    if (token) {
      send({ type: 'hello', token })
    } else {
      setState('unpaired')
    }
    broadcastState()
  }

  socket.onmessage = (event) => {
    let msg = null
    try {
      msg = JSON.parse(event.data)
    } catch {
      return
    }
    handleMessage(msg)
  }

  socket.onclose = () => {
    if (ws === socket) ws = null
    wsState = 'disconnected'
    rejectAllPending('disconnected')
    broadcastState()
    scheduleReconnect(opened)
  }

  socket.onerror = () => {
    try {
      socket.close()
    } catch {
      void 0
    }
  }
}

function scheduleReconnect(wasOpen) {
  if (foundPort != null && !wasOpen) {
    failuresSinceFound += 1
    if (failuresSinceFound >= 3) {
      foundPort = null
      failuresSinceFound = 0
    }
  }
  if (foundPort == null && !wasOpen) discoveryIndex += 1

  const scanning = foundPort == null
  let delay
  if (scanning) {
    const completedSweep = discoveryIndex > 0 && discoveryIndex % PORT_TRIES === 0
    delay = completedSweep ? 5000 : 250
  } else {
    delay = reconnectDelay
    reconnectDelay = Math.min(reconnectDelay * 2, RECONNECT_MAX)
  }
  clearTimeout(reconnectTimer)
  reconnectTimer = setTimeout(connect, delay)
}

function rejectAllPending(reason) {
  for (const [, entry] of pending) entry.resolve({ error: reason })
  pending.clear()
  while (pairWaiters.length) pairWaiters.shift()({ ok: false, reason })
}

async function handleMessage(msg) {
  switch (msg.type) {
    case 'ready':
      setState('ready')
      return
    case 'locked':
      setState('locked')
      resolveReq(msg.reqId, { error: 'locked' })
      return
    case 'unauthorized':
      token = null
      await api.storage.local.remove('token')
      setState('unpaired')
      return
    case 'pairChallenge':
      if (pendingCode) {
        const proof = await hmacHex(pendingCode, msg.nonce)
        send({ type: 'pairProof', proof })
      }
      return
    case 'paired':
      token = msg.token
      pendingCode = null
      await api.storage.local.set({ token })
      setState('ready')
      while (pairWaiters.length) pairWaiters.shift()({ ok: true })
      return
    case 'pairFailed':
      pendingCode = null
      while (pairWaiters.length) pairWaiters.shift()({ ok: false, reason: msg.reason })
      return
    case 'matches':
      resolveReq(msg.reqId, { items: msg.items || [] })
      return
    case 'secret':
      resolveReq(msg.reqId, {
        secret: { login: msg.login, password: msg.password, totp: msg.totp }
      })
      return
    case 'error':
      resolveReq(msg.reqId, { error: msg.reason || 'error' })
      return
    default:
      return
  }
}

function resolveReq(reqId, value) {
  const entry = pending.get(reqId)
  if (!entry) return
  clearTimeout(entry.timer)
  pending.delete(reqId)
  entry.resolve(value)
}

function request(payload, timeoutMs = 8000) {
  return new Promise((resolve) => {
    if (!send(payload)) {
      resolve({ error: 'disconnected' })
      return
    }
    const timer = setTimeout(() => {
      pending.delete(payload.reqId)
      resolve({ error: 'timeout' })
    }, timeoutMs)
    pending.set(payload.reqId, { resolve, timer })
  })
}

async function ensureConnected(timeoutMs = 4000) {
  if (ws && ws.readyState === WebSocket.OPEN) return true
  connect()
  const start = Date.now()
  while (Date.now() - start < timeoutMs) {
    if (ws && ws.readyState === WebSocket.OPEN) return true
    await new Promise((r) => setTimeout(r, 150))
  }
  return false
}

async function doPair(code) {
  pendingCode = code
  const ok = await ensureConnected()
  if (!ok) return { ok: false, reason: 'disconnected' }
  return new Promise((resolve) => {
    pairWaiters.push(resolve)
    send({ type: 'pairHello' })
    setTimeout(() => {
      const idx = pairWaiters.indexOf(resolve)
      if (idx !== -1) {
        pairWaiters.splice(idx, 1)
        resolve({ ok: false, reason: 'timeout' })
      }
    }, 10000)
  })
}

async function doQuery(url) {
  if (!(await ensureConnected())) return { items: [], error: 'disconnected' }
  if (token && appState !== 'ready') send({ type: 'hello', token })
  return request({ type: 'query', reqId: nextReqId(), url })
}

async function doFill(id, fields) {
  if (!(await ensureConnected())) return { error: 'disconnected' }
  return request({ type: 'fill', reqId: nextReqId(), id, fields })
}

async function revokeLocal() {
  token = null
  pendingCode = null
  await api.storage.local.remove('token')
  setState('unpaired')
  return { ok: true }
}

api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  ;(async () => {
    switch (msg && msg.cmd) {
      case 'getState':
        await ensureConnected(2000)
        sendResponse({ wsState, appState })
        return
      case 'pair':
        sendResponse(await doPair(String(msg.code || '')))
        return
      case 'query':
        sendResponse(await doQuery(msg.url))
        return
      case 'fill':
        sendResponse(await doFill(msg.id, msg.fields || ['login', 'password', 'totp']))
        return
      case 'fillActive': {
        const result = await doFill(msg.id, ['login', 'password', 'totp'])
        if (result.secret && sender.tab && sender.tab.id != null) {
          api.tabs.sendMessage(sender.tab.id, { cmd: 'doFill', secret: result.secret })
        } else if (result.secret) {
          const [tab] = await api.tabs.query({ active: true, currentWindow: true })
          if (tab) api.tabs.sendMessage(tab.id, { cmd: 'doFill', secret: result.secret })
        }
        sendResponse(result)
        return
      }
      case 'revokeLocal':
        sendResponse(await revokeLocal())
        return
      default:
        sendResponse({ error: 'unknown_cmd' })
    }
  })()
  return true
})

loadToken().then(connect)
